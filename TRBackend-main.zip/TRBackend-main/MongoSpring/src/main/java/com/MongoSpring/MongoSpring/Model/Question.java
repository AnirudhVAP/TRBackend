package com.MongoSpring.MongoSpring.Model;

public class Question {
}
